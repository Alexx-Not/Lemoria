
// Aguarda o carregamento completo da página
document.addEventListener('DOMContentLoaded', function() {

    // --- Funções de Controle de Página ---

    // Função para mostrar uma seção e esconder as outras
    function showSection(sectionId) {
        const sections = document.querySelectorAll('.page-section');
        sections.forEach(section => {
            section.classList.remove('active');
        });
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
        }

        // Ajusta a classe do body para estilização específica do dashboard
        if (sectionId === 'dashboard-page') {
            document.body.classList.add('dashboard-body');
        } else {
            document.body.classList.remove('dashboard-body');
        }
    }

    // --- Lógica de Tema (Dark/Light Mode) ---
    const themeToggleBtn = document.getElementById('theme-toggle');

    function loadTheme() {
        const savedTheme = localStorage.getItem('theme') || 'light';
        document.body.classList.toggle('dark-mode', savedTheme === 'dark');
        if (themeToggleBtn) {
            themeToggleBtn.textContent = savedTheme === 'dark' ? 'Modo Claro' : 'Modo Escuro';
        }
    }

    function toggleTheme() {
        const isDarkMode = document.body.classList.toggle('dark-mode');
        const newTheme = isDarkMode ? 'dark' : 'light';
        localStorage.setItem('theme', newTheme);
        if (themeToggleBtn) {
            themeToggleBtn.textContent = isDarkMode ? 'Modo Claro' : 'Modo Escuro';
        }
    }

    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', toggleTheme);
    }

    loadTheme();

    // --- Lógica de Login/Cadastro ---

    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const showRegisterBtn = document.getElementById('show-register');
    const showLoginBtn = document.getElementById('show-login');
    const showTermsBtn = document.getElementById('show-terms');
    const backToRegisterBtn = document.getElementById('back-to-register');

    if (showRegisterBtn) {
        showRegisterBtn.addEventListener('click', function(e) {
            e.preventDefault();
            loginForm.classList.remove('active');
            registerForm.classList.add('active');
            loginForm.querySelector('form').reset();
        });
    }

    if (showLoginBtn) {
        showLoginBtn.addEventListener('click', function(e) {
            e.preventDefault();
            registerForm.classList.remove('active');
            loginForm.classList.add('active');
            registerForm.querySelector('form').reset();
        });
    }

    if (showTermsBtn) {
        showTermsBtn.addEventListener('click', function(e) {
            e.preventDefault();
            showSection('terms-page');
        });
    }

    if (backToRegisterBtn) {
        backToRegisterBtn.addEventListener('click', function(e) {
            e.preventDefault();
            showSection('login-page');
            registerForm.classList.add('active');
            loginForm.classList.remove('active');
        });
    }

    // Lógica de submit do formulário de login
    const loginFormElement = loginForm.querySelector('form');
    if (loginFormElement) {
        loginFormElement.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('login-email').value.trim();
            const password = document.getElementById('login-password').value;
            const users = JSON.parse(localStorage.getItem('lemoria_users') || '[]');
            const user = users.find(u => u.email === email && u.password === password);

            if (user) {
                localStorage.setItem('lemoria_user', JSON.stringify(user));
                showMessage('Login bem-sucedido!', 'success');
                setTimeout(() => {
                    showSection('dashboard-page');
                    if (!window.reminderManager) {
                        window.reminderManager = new ReminderManager();
                    }
                }, 1500);
            } else {
                showMessage('Email ou senha incorretos.', 'error');
            }
        });
    }

    // Lógica de submit do formulário de cadastro
    const registerFormElement = registerForm.querySelector('form');
    if (registerFormElement) {
        registerFormElement.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('register-name').value.trim();
            const email = document.getElementById('register-email').value.trim();
            const password = document.getElementById('register-password').value;
            const users = JSON.parse(localStorage.getItem('lemoria_users') || '[]');

            if (users.find(u => u.email === email)) {
                showMessage('Este email já está cadastrado.', 'error');
                return;
            }

            const newUser = { name, email, password };
            users.push(newUser);
            localStorage.setItem('lemoria_users', JSON.stringify(users));
            showMessage('Conta criada com sucesso! Faça o login.', 'success');
            setTimeout(() => {
                registerForm.classList.remove('active');
                loginForm.classList.add('active');
                registerFormElement.reset();
            }, 2000);
        });
    }

    // --- Classe de Gerenciamento do Dashboard ---

    class ReminderManager {
        constructor() {
            this.reminders = JSON.parse(localStorage.getItem('lemoria_reminders') || '[]');
            this.userNameElement = document.getElementById('user-name');
            this.logoutBtn = document.getElementById('logout-btn');
            this.reminderForm = document.getElementById('reminder-form');
            this.remindersList = document.getElementById('reminders-list');
            this.editModal = document.getElementById('edit-modal');
            this.editForm = document.getElementById('edit-form');
            this.cancelEditBtn = document.getElementById('cancel-edit');

            this.checkUser();
            this.loadListeners();
            this.renderReminders();
        }

        checkUser() {
            const loggedUser = JSON.parse(localStorage.getItem('lemoria_user'));
            if (loggedUser && this.userNameElement) {
                this.userNameElement.textContent = loggedUser.name || loggedUser.email;
            }
        }

        loadListeners() {
            if (this.logoutBtn) {
                this.logoutBtn.addEventListener('click', () => {
                    localStorage.removeItem('lemoria_user');
                    showSection('login-page');
                    loginForm.classList.add('active');
                    registerForm.classList.remove('active');
                });
            }
            if (this.reminderForm) {
                this.reminderForm.addEventListener('submit', this.addReminder.bind(this));
            }
            if (this.remindersList) {
                this.remindersList.addEventListener('click', this.handleReminderActions.bind(this));
            }
            this.filterButtons = document.querySelectorAll('.filter-btn');
            this.search = document.getElementById('search-input');
            this.filterButtons.forEach(btn => {
                btn.addEventListener('click', this.filterReminders.bind(this));
            });
            if (this.search) {
                this.search.addEventListener('input', this.searchReminders.bind(this));
            }
            this.cancelEditBtn = document.getElementById('cancel-edit');
            if (this.cancelEditBtn) {
                this.cancelEditBtn.addEventListener('click', this.closeModal.bind(this));
            }
            if (this.editForm) {
                this.editForm.addEventListener('submit', this.saveEdit.bind(this));
            }
            this.notification = document.getElementById('notification');
            this.notificationClose = this.notification.querySelector('.notification-close');
            if (this.notificationClose) {
                this.notificationClose.addEventListener('click', () => this.notification.classList.remove('active'));
            }
            window.addEventListener('click', (e) => {
                if (e.target === this.editModal) {
                    this.closeModal();
                }
            });
        }

        saveReminders() {
            localStorage.setItem('lemoria_reminders', JSON.stringify(this.reminders));
        }

        addReminder(e) {
            e.preventDefault();
            
            const title = document.getElementById('reminder-title').value.trim();
            const date = document.getElementById('reminder-date').value;
            const time = document.getElementById('reminder-time').value;
            const message = document.getElementById('reminder-message').value.trim();
            
            const newReminder = {
                id: Date.now(),
                title,
                date,
                time,
                message,
                completed: false,
                createdAt: new Date().toISOString()
            };

            this.reminders.push(newReminder);
            this.saveReminders();
            this.renderReminders();
            this.reminderForm.reset();
            showMessage('Recado Adicionado', 'success');
        }

        handleReminderActions(e) {
            const target = e.target;
            const card = target.closest('.reminder-card');
            if (!card) return;

            const id = parseInt(card.dataset.id);

            if (target.classList.contains('btn-delete')) {
                this.deleteReminder(id);
            } else if (target.classList.contains('btn-mark')) {
                this.toggleCompleted(id);
            } else if (target.classList.contains('btn-edit')) {
                this.openEditModal(id);
            }
        }

        deleteReminder(id) {
            const reminderToDelete = this.reminders.find(r => r.id === id);
            
            if (!reminderToDelete) {
                showMessage('Erro: Recado não encontrado.', 'error');
                return;
            }

            if (!reminderToDelete.completed) {
                showMessage('Atenção: Você só pode excluir recados que já foram visualizados.', 'error');
                return;
            }

            this.reminders = this.reminders.filter(r => r.id !== id);
            this.saveReminders();
            this.renderReminders();
            showMessage('Recado Excluído', 'success');
        }

        toggleCompleted(id) {
            const reminder = this.reminders.find(r => r.id === id);
            if (reminder) {
                reminder.completed = !reminder.completed;
                this.saveReminders();
                this.renderReminders();
                showMessage('Status Atualizado', 'success');
            }
        }

        openEditModal(id) {
            const reminder = this.reminders.find(r => r.id === id);
            if (reminder) {
                this.editReminderId = id;
                document.getElementById('edit-title').value = reminder.title;
                document.getElementById('edit-date').value = reminder.date;
                document.getElementById('edit-time').value = reminder.time;
                document.getElementById('edit-message').value = reminder.message;
                this.editModal.classList.add('active');
            }
        }

        closeModal() {
            this.editModal.classList.remove('active');
            this.editReminderId = null;
            this.editForm.reset();
        }

        saveEdit(e) {
            e.preventDefault();
            
            const title = document.getElementById('edit-title').value.trim();
            const date = document.getElementById('edit-date').value;
            const time = document.getElementById('edit-time').value;
            const message = document.getElementById('edit-message').value.trim();

            const index = this.reminders.findIndex(r => r.id === this.editReminderId);
            if (index !== -1) {
                this.reminders[index] = {
                    ...this.reminders[index],
                    title,
                    date,
                    time,
                    message
                };
                this.saveReminders();
                this.renderReminders();
                this.closeModal();
                showMessage('Recado Editado', 'success');
            }
        }

        filterReminders(e) {
            const filter = e.target.dataset.filter;
            this.filterButtons.forEach(btn => btn.classList.remove('active'));
            e.target.classList.add('active');
            this.renderReminders(filter);
        }

        searchReminders() {
            this.renderReminders(null, this.search.value.toLowerCase());
        }

        renderReminders(filter = 'all', search = '') {
            let filteredReminders = this.reminders.sort((a, b) => new Date(a.date + ' ' + a.time) - new Date(b.date + ' ' + b.time));

            if (filter === 'pending') {
                filteredReminders = filteredReminders.filter(r => !r.completed);
            } else if (filter === 'completed') {
                filteredReminders = filteredReminders.filter(r => r.completed);
            }

            if (search) {
                filteredReminders = filteredReminders.filter(r => 
                    r.title.toLowerCase().includes(search) || 
                    r.message.toLowerCase().includes(search)
                );
            }

            if (this.remindersList) {
                this.remindersList.innerHTML = '';

                if (filteredReminders.length === 0) {
                    this.remindersList.innerHTML = `
                        <div class="empty-state">
                            <p>${search ? 'Nenhum recado encontrado para sua busca.' : 'Nenhum recado criado ainda. Crie um novo recado para começar!'}</p>
                        </div>
                    `;
                    return;
                }

                filteredReminders.forEach(reminder => {
                    const card = this.createReminderCard(reminder);
                    this.remindersList.appendChild(card);
                });
            }
        }

        createReminderCard(reminder) {
            const card = document.createElement('div');
            card.className = `reminder-card ${reminder.completed ? 'completed' : ''}`;
            card.dataset.id = reminder.id;
            
            const date = new Date(reminder.date + 'T' + reminder.time);
            const formattedDate = date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
            const formattedTime = date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
            
            card.innerHTML = `
                <div class="reminder-header">
                    <h3 class="reminder-title">${reminder.title}</h3>
                    <span class="reminder-badge ${reminder.completed ? 'completed' : ''}">${reminder.completed ? 'Visualizado' : 'Pendente'}</span>
                </div>
                <div class="reminder-datetime">
                    <span class="reminder-date">${formattedDate}</span>
                    <span class="reminder-time">${formattedTime}</span>
                </div>
                <p class="reminder-message">${reminder.message}</p>
                <div class="reminder-actions">
                    <button class="btn-small btn-edit">Editar</button>
                    <button class="btn-small btn-mark">${reminder.completed ? 'Marcar como Pendente' : 'Marcar como Visualizado'}</button>
                    <button class="btn-small btn-delete">Excluir</button>
                </div>
            `;
            return card;
        }

    }

    // --- Funções Comuns ---

    function showMessage(message, type) {
        const notification = document.getElementById('notification');
        const title = document.getElementById('notification-title');
        const msg = document.getElementById('notification-message');
        
        if(notification && title && msg){
            title.textContent = type === 'success' ? 'Sucesso!' : 'Erro!';
            msg.textContent = message;
            notification.classList.add('active');
            setTimeout(() => {
                notification.classList.remove('active');
            }, 4000);
        }
    }

    // --- Inicialização ---

    function checkInitialState() {
        const loggedUser = localStorage.getItem('lemoria_user');
        if (loggedUser) {
            showSection('dashboard-page');
            if (!window.reminderManager) {
                window.reminderManager = new ReminderManager();
            }
        } else {
            showSection('login-page');
        }
    }

    checkInitialState();

});

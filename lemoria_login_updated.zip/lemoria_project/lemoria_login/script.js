// Aguarda o carregamento completo da página
document.addEventListener('DOMContentLoaded', function() {
    // --- Funções de Login/Cadastro ---

    // Função de verificação de login para redirecionar se o usuário já estiver logado
    function checkLoginStatus() {
        const loggedUser = localStorage.getItem('lemoria_user');
        // Se estiver na página de login (index.html) e o usuário estiver logado, redireciona
        if (loggedUser && window.location.pathname.includes('index.html')) {
            window.location.href = 'dashboard.html';
        }
        // Se estiver no dashboard e o usuário NÃO estiver logado, redireciona para o login
        if (!loggedUser && window.location.pathname.includes('dashboard.html')) {
            window.location.href = 'index.html';
        }
    }

    // Executa a verificação de status de login ao carregar a página
    checkLoginStatus();

    // Elementos dos formulários
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    
    // Botões para alternar entre formulários
    const showRegisterBtn = document.getElementById('show-register');
    const showLoginBtn = document.getElementById('show-login');
    
    // Formulários
    const loginFormElement = loginForm.querySelector('form');
    const registerFormElement = registerForm.querySelector('form');

    // Função para alternar para o formulário de cadastro
    showRegisterBtn.addEventListener('click', function(e) {
        e.preventDefault();
        loginForm.classList.remove('active');
        registerForm.classList.add('active');
        
        // Limpa os campos do formulário de login
        loginFormElement.reset();
    });

    // Função para alternar para o formulário de login
    showLoginBtn.addEventListener('click', function(e) {
        e.preventDefault();
        registerForm.classList.remove('active');
        loginForm.classList.add('active');
        
        // Limpa os campos do formulário de cadastro
        registerFormElement.reset();
    });

    // Manipulação do formulário de login
    loginFormElement.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('login-email').value.trim();
        const password = document.getElementById('login-password').value;
        const rememberMe = document.getElementById('remember-me').checked;
        
        // Validação básica
        if (!email || !password) {
            showMessage('Por favor, preencha todos os campos.', 'error');
            return;
        }
        
        // Validação de email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            showMessage('Por favor, insira um email válido.', 'error');
            return;
        }
        
        // Buscar usuário cadastrado
        const users = JSON.parse(localStorage.getItem('lemoria_users') || '[]');
        const user = users.find(u => u.email === email);
        
        // Validar credenciais
        if (!user) {
            showMessage('Email não cadastrado. Por favor, crie uma conta.', 'error');
            return;
        }
        
        if (user.password !== password) {
            showMessage('Senha incorreta. Tente novamente.', 'error');
            return;
        }
        
        // Login bem-sucedido
        showMessage('De novo seu chato!', 'success');
        
        // Armazenar dados do usuário logado
        const loggedUser = {
            email: user.email,
            name: user.name,
            loginTime: new Date().toISOString(),
            rememberMe: rememberMe
        };
        
        localStorage.setItem('lemoria_user', JSON.stringify(loggedUser));
        
        // Log para demonstração
        console.log('Login realizado:', {
            email: email,
            password: '***',
            rememberMe: rememberMe
        });
        
        // Redirecionar para o dashboard após 1.5 segundos
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1500);
    });

    // Manipulação do formulário de cadastro
    registerFormElement.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const name = document.getElementById('register-name').value.trim();
        const email = document.getElementById('register-email').value.trim();
        const password = document.getElementById('register-password').value;
        const confirmPassword = document.getElementById('confirm-password').value;
        const acceptTerms = document.getElementById('accept-terms').checked;
        
        // Validações básicas
        if (!name || !email || !password || !confirmPassword) {
            showMessage('Por favor, preencha todos os campos.', 'error');
            return;
        }
        
        if (password !== confirmPassword) {
            showMessage('As senhas não coincidem.', 'error');
            return;
        }
        
        if (password.length < 6) {
            showMessage('A senha deve ter pelo menos 6 caracteres.', 'error');
            return;
        }
        
        if (!acceptTerms) {
            showMessage('Você deve aceitar os termos de uso.', 'error');
            return;
        }
        
        // Validação de email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            showMessage('Por favor, insira um email válido.', 'error');
            return;
        }
        
        // Verificar se o email já está cadastrado
        const users = JSON.parse(localStorage.getItem('lemoria_users') || '[]');
        if (users.find(u => u.email === email)) {
            showMessage('Este email já está cadastrado. Faça login ou use outro email.', 'error');
            return;
        }
        
        // Criar novo usuário
        const newUser = {
            email: email,
            name: name,
            password: password, // Em produção, isso deveria ser criptografado
            registeredAt: new Date().toISOString()
        };
        
        // Salvar novo usuário na lista
        users.push(newUser);
        localStorage.setItem('lemoria_users', JSON.stringify(users));
        
        // Cadastro bem-sucedido
        showMessage('Conta criada com sucesso! Você será redirecionado para o login.', 'success');
        
        // Log para demonstração
        console.log('Cadastro realizado:', {
            name: name,
            email: email,
            password: '***'
        });
        
        // Após cadastro bem-sucedido, volta para o login
        setTimeout(() => {
            registerForm.classList.remove('active');
            loginForm.classList.add('active');
            registerFormElement.reset();
        }, 2000);
    });

    // Função para exibir mensagens
    function showMessage(message, type) {
        // Remove mensagem anterior se existir
        const existingMessage = document.querySelector('.message');
        if (existingMessage) {
            existingMessage.remove();
        }
        
        // Cria nova mensagem
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        messageDiv.textContent = message;
        
        // Estilos da mensagem
        messageDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 10px;
            color: white;
            font-weight: 600;
            z-index: 1000;
            animation: slideIn 0.3s ease-out;
            max-width: 300px;
            word-wrap: break-word;
        `;
        
        if (type === 'success') {
            messageDiv.style.background = 'linear-gradient(135deg, #27ae60, #2ecc71)';
        } else if (type === 'error') {
            messageDiv.style.background = 'linear-gradient(135deg, #e74c3c, #c0392b)';
        }
        
        document.body.appendChild(messageDiv);
        
        // Remove a mensagem após 4 segundos
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.style.animation = 'slideOut 0.3s ease-in';
                setTimeout(() => {
                    messageDiv.remove();
                }, 5000);
            }
        }, 5000);
    }

    // Adiciona animações CSS para as mensagens
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
        
        .message {
            word-wrap: break-word;
            white-space: pre-wrap;
        }
    `;
    document.head.appendChild(style);

    // Validação em tempo real para senhas
    const registerPassword = document.getElementById('register-password');
    const confirmPassword = document.getElementById('confirm-password');
    
    confirmPassword.addEventListener('input', function() {
        if (this.value && registerPassword.value) {
            if (this.value === registerPassword.value) {
                this.classList.remove('input-error');
                this.classList.add('input-success');
            } else {
                this.classList.remove('input-success');
                this.classList.add('input-error');
            }
        } else {
            this.classList.remove('input-error', 'input-success');
        }
    });

    // Validação de email em tempo real
    const emailInputs = document.querySelectorAll('input[type="email"]');
    emailInputs.forEach(input => {
        input.addEventListener('blur', function() {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (this.value) {
                if (emailRegex.test(this.value)) {
                    this.classList.remove('input-error');
                    this.classList.add('input-success');
                } else {
                    this.classList.remove('input-success');
                    this.classList.add('input-error');
                }
            } else {
                this.classList.remove('input-error', 'input-success');
            }
        });
    });

    // Efeito de foco nos inputs
    const allInputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="password"]');
    allInputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentNode.style.transform = 'scale(1.02)';
            this.parentNode.style.transition = 'transform 0.2s ease';
        });
        
        input.addEventListener('blur', function() {
            this.parentNode.style.transform = 'scale(1)';
        });
    });



});

// Dashboard JavaScript - Gerenciamento de Recados

class ReminderManager {
    constructor() {
        this.reminders = [];
        this.currentFilter = 'all';
        this.currentSearch = '';
        this.editingId = null;
        this.notificationInterval = null;
        
        this.init();
    }

    init() {
        this.loadReminders();
        this.setupEventListeners();
        this.renderReminders();
        this.startNotificationCheck();
        this.setMinDate();
        this.displayUserName();
    }

    // ==================== Event Listeners ====================
    setupEventListeners() {
        // Criar novo recado
        document.getElementById('reminder-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.addReminder();
        });

        // Logout
        document.getElementById('logout-btn').addEventListener('click', () => {
            this.logout();
        });

        // Filtros
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                this.currentFilter = e.target.dataset.filter;
                this.renderReminders();
            });
        });

        // Busca
        document.getElementById('search-input').addEventListener('input', (e) => {
            this.currentSearch = e.target.value.toLowerCase();
            this.renderReminders();
        });

        // Modal
        const editModal = document.getElementById('edit-modal');
        const modalClose = document.querySelector('.modal-close');
        const cancelEdit = document.getElementById('cancel-edit');

        modalClose.addEventListener('click', () => {
            this.closeModal();
        });

        cancelEdit.addEventListener('click', () => {
            this.closeModal();
        });

        document.getElementById('edit-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.updateReminder();
        });

        // Fechar modal ao clicar fora
        editModal.addEventListener('click', (e) => {
            if (e.target === editModal) {
                this.closeModal();
            }
        });

        // Notificação
        document.querySelector('.notification-close').addEventListener('click', () => {
            this.closeNotification();
        });
    }

    // ==================== CRUD Operations ====================
    addReminder() {
        const title = document.getElementById('reminder-title').value.trim();
        const date = document.getElementById('reminder-date').value;
        const time = document.getElementById('reminder-time').value;
        const message = document.getElementById('reminder-message').value.trim();

        if (!title || !date || !time || !message) {
            this.showMessage('Por favor, preencha todos os campos.', 'error');
            return;
        }

        const reminder = {
            id: Date.now(),
            title,
            date,
            time,
            message,
            completed: false,
            createdAt: new Date().toISOString()
        };

        this.reminders.push(reminder);
        this.saveReminders();
        this.renderReminders();
        
        // Limpar formulário
        document.getElementById('reminder-form').reset();
        
        this.showMessage('Recado adicionado com sucesso!', 'success');
    }

    deleteReminder(id) {
        const reminder = this.reminders.find(r => r.id === id);

        if (!reminder) return;

        // Regra de validação: só pode deletar se estiver visualizado (completed: true)
        if (!reminder.completed) {
            this.showMessage('Atenção: Só é possível deletar um recado quando ele for visualizado.', 'error');
            return;
        }

        if (confirm('Tem certeza que deseja deletar este recado?')) {
            this.reminders = this.reminders.filter(r => r.id !== id);
            this.saveReminders();
            this.renderReminders();
            this.showMessage('Recado deletado com sucesso!', 'success');
        }
    }

    openEditModal(id) {
        const reminder = this.reminders.find(r => r.id === id);
        if (!reminder) return;

        this.editingId = id;
        document.getElementById('edit-title').value = reminder.title;
        document.getElementById('edit-date').value = reminder.date;
        document.getElementById('edit-time').value = reminder.time;
        document.getElementById('edit-message').value = reminder.message;

        document.getElementById('edit-modal').classList.add('active');
    }

    closeModal() {
        document.getElementById('edit-modal').classList.remove('active');
        this.editingId = null;
        document.getElementById('edit-form').reset();
    }

    updateReminder() {
        if (this.editingId === null) return;

        const title = document.getElementById('edit-title').value.trim();
        const date = document.getElementById('edit-date').value;
        const time = document.getElementById('edit-time').value;
        const message = document.getElementById('edit-message').value.trim();

        if (!title || !date || !time || !message) {
            this.showMessage('Por favor, preencha todos os campos.', 'error');
            return;
        }

        const reminder = this.reminders.find(r => r.id === this.editingId);
        if (reminder) {
            reminder.title = title;
            reminder.date = date;
            reminder.time = time;
            reminder.message = message;

            this.saveReminders();
            this.renderReminders();
            this.closeModal();
            this.showMessage('Recado atualizado com sucesso!', 'success');
        }
    }

    markAsCompleted(id) {
        const reminder = this.reminders.find(r => r.id === id);
        if (reminder) {
            reminder.completed = !reminder.completed;
            this.saveReminders();
            this.renderReminders();
        }
    }

    // ==================== Rendering ====================
    renderReminders() {
        const remindersList = document.getElementById('reminders-list');
        let filtered = this.getFilteredReminders();

        if (filtered.length === 0) {
            remindersList.innerHTML = '<div class="empty-state"><p>Nenhum recado encontrado.</p></div>';
            return;
        }

        remindersList.innerHTML = filtered.map(reminder => this.createReminderCard(reminder)).join('');
        
        // Adicionar event listeners aos botões
        document.querySelectorAll('.btn-edit').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.target.dataset.id);
                this.openEditModal(id);
            });
        });

        document.querySelectorAll('.btn-delete').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.target.dataset.id);
                this.deleteReminder(id);
            });
        });

        document.querySelectorAll('.btn-mark').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.target.dataset.id);
                this.markAsCompleted(id);
            });
        });
    }

    createReminderCard(reminder) {
        const isCompleted = reminder.completed;
        const completedClass = isCompleted ? 'completed' : '';
        const buttonText = isCompleted ? 'Desmarcar' : 'Marcar como Visto';
        const buttonClass = isCompleted ? 'btn-mark' : 'btn-mark';

        return `
            <div class="reminder-card ${completedClass}">
                <div class="reminder-header">
                    <h3 class="reminder-title">${this.escapeHtml(reminder.title)}</h3>
                    <span class="reminder-badge ${completedClass}">${isCompleted ? 'Visto' : 'Pendente'}</span>
                </div>
                <div class="reminder-datetime">
                    <span class="reminder-date">${this.formatDate(reminder.date)}</span>
                    <span class="reminder-time">${reminder.time}</span>
                </div>
                <div class="reminder-message">${this.escapeHtml(reminder.message)}</div>
                <div class="reminder-actions">
                    <button class="btn-small btn-mark" data-id="${reminder.id}">${buttonText}</button>
                    <button class="btn-small btn-edit" data-id="${reminder.id}">Editar</button>
                    <button class="btn-small btn-delete" data-id="${reminder.id}">Deletar</button>
                </div>
            </div>
        `;
    }

    getFilteredReminders() {
        let filtered = this.reminders;

        // Filtro por status
        if (this.currentFilter === 'pending') {
            filtered = filtered.filter(r => !r.completed);
        } else if (this.currentFilter === 'completed') {
            filtered = filtered.filter(r => r.completed);
        }

        // Filtro por busca
        if (this.currentSearch) {
            filtered = filtered.filter(r =>
                r.title.toLowerCase().includes(this.currentSearch) ||
                r.message.toLowerCase().includes(this.currentSearch)
            );
        }

        // Ordenar por data e hora
        return filtered.sort((a, b) => {
            const dateTimeA = new Date(`${a.date}T${a.time}`);
            const dateTimeB = new Date(`${b.date}T${b.time}`);
            return dateTimeA - dateTimeB;
        });
    }

    // ==================== Notifications ====================
    startNotificationCheck() {
        // Verificar a cada minuto
        this.notificationInterval = setInterval(() => {
            this.checkForNotifications();
        }, 60000); // 60 segundos

        // Verificar imediatamente
        this.checkForNotifications();
    }

    checkForNotifications() {
        const now = new Date();
        const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
        const currentDate = now.toISOString().split('T')[0];

        this.reminders.forEach(reminder => {
            if (!reminder.completed && reminder.date === currentDate && reminder.time === currentTime) {
                this.showNotification(reminder);
                // Marcar como visualizado automaticamente após notificação
                setTimeout(() => {
                    reminder.completed = true;
                    this.saveReminders();
                    this.renderReminders();
                }, 5000);
            }
        });
    }

    showNotification(reminder) {
        const notification = document.getElementById('notification');
        document.getElementById('notification-title').textContent = reminder.title;
        document.getElementById('notification-message').textContent = reminder.message;
        
        notification.classList.add('active');

        // Som de notificação (opcional)
        this.playNotificationSound();

        // Fechar após 10 segundos
        setTimeout(() => {
            this.closeNotification();
        }, 10000);
    }

    closeNotification() {
        document.getElementById('notification').classList.remove('active');
    }

    playNotificationSound() {
        // Criar um som simples usando Web Audio API
        try {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();

            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);

            oscillator.frequency.value = 800;
            oscillator.type = 'sine';

            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);

            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.5);
        } catch (e) {
            console.log('Notificação de som não disponível');
        }
    }

    // ==================== Storage ====================
    saveReminders() {
        localStorage.setItem('lemoria_reminders', JSON.stringify(this.reminders));
    }

    loadReminders() {
        const stored = localStorage.getItem('lemoria_reminders');
        this.reminders = stored ? JSON.parse(stored) : [];
    }

    // ==================== User ====================
    displayUserName() {
        const user = JSON.parse(localStorage.getItem('lemoria_user') || '{}');
        const userName = user.name || 'Usuário';
        document.getElementById('user-name').textContent = userName;
    }

    logout() {
        localStorage.removeItem('lemoria_user');
        window.location.href = 'index.html';
    }

    // ==================== Utilities ====================
    showMessage(message, type) {
        const notification = document.getElementById('notification');
        document.getElementById('notification-title').textContent = type === 'success' ? 'Sucesso' : 'Erro';
        document.getElementById('notification-message').textContent = message;
        
        notification.classList.add('active');

        setTimeout(() => {
            notification.classList.remove('active');
        }, 3000);
    }

    formatDate(dateString) {
        const date = new Date(dateString + 'T00:00:00');
        return date.toLocaleDateString('pt-BR', { 
            weekday: 'short', 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric' 
        });
    }

    setMinDate() {
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('reminder-date').min = today;
        document.getElementById('edit-date').min = today;
    }

    escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, m => map[m]);
    }
}

// Inicializar quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se o usuário está logado
    const user = localStorage.getItem('lemoria_user');
    if (!user) {
        window.location.href = 'index.html';
        return;
    }

    // Inicializar o gerenciador de recados
    new ReminderManager();
});


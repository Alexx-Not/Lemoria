// Aguarda o carregamento completo da página
document.addEventListener('DOMContentLoaded', function() {
    // Elementos dos formulários
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    
    // Botões para alternar entre formulários
    const showRegisterBtn = document.getElementById('show-register');
    const showLoginBtn = document.getElementById('show-login');
    
    // Formulários
    const loginFormElement = loginForm.querySelector('form');
    const registerFormElement = registerForm.querySelector('form');

    // Função para alternar para o formulário de cadastro
    showRegisterBtn.addEventListener('click', function(e) {
        e.preventDefault();
        loginForm.classList.remove('active');
        registerForm.classList.add('active');
        
        // Limpa os campos do formulário de login
        loginFormElement.reset();
    });

    // Função para alternar para o formulário de login
    showLoginBtn.addEventListener('click', function(e) {
        e.preventDefault();
        registerForm.classList.remove('active');
        loginForm.classList.add('active');
        
        // Limpa os campos do formulário de cadastro
        registerFormElement.reset();
    });

    // Manipulação do formulário de login
    loginFormElement.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('login-email').value.trim();
        const password = document.getElementById('login-password').value;
        const rememberMe = document.getElementById('remember-me').checked;
        
        // Validação básica
        if (!email || !password) {
            showMessage('Por favor, preencha todos os campos.', 'error');
            return;
        }
        
        // Validação de email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            showMessage('Por favor, insira um email válido.', 'error');
            return;
        }
        
        // Buscar usuário cadastrado
        const users = JSON.parse(localStorage.getItem('lemoria_users') || '[]');
        const user = users.find(u => u.email === email);
        
        // Validar credenciais
        if (!user) {
            showMessage('Email não cadastrado. Por favor, crie uma conta.', 'error');
            return;
        }
        
        if (user.password !== password) {
            showMessage('Senha incorreta. Tente novamente.', 'error');
            return;
        }
        
        // Login bem-sucedido
        showMessage('Login realizado com sucesso!', 'success');
        
        // Armazenar dados do usuário logado
        const loggedUser = {
            email: user.email,
            name: user.name,
            loginTime: new Date().toISOString(),
            rememberMe: rememberMe
        };
        
        localStorage.setItem('lemoria_user', JSON.stringify(loggedUser));
        
        // Log para demonstração
        console.log('Login realizado:', {
            email: email,
            password: '***',
            rememberMe: rememberMe
        });
        
        // Redirecionar para o dashboard após 1.5 segundos
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1500);
    });

    // Manipulação do formulário de cadastro
    registerFormElement.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const name = document.getElementById('register-name').value.trim();
        const email = document.getElementById('register-email').value.trim();
        const password = document.getElementById('register-password').value;
        const confirmPassword = document.getElementById('confirm-password').value;
        const acceptTerms = document.getElementById('accept-terms').checked;
        
        // Validações básicas
        if (!name || !email || !password || !confirmPassword) {
            showMessage('Por favor, preencha todos os campos.', 'error');
            return;
        }
        
        if (password !== confirmPassword) {
            showMessage('As senhas não coincidem.', 'error');
            return;
        }
        
        if (password.length < 6) {
            showMessage('A senha deve ter pelo menos 6 caracteres.', 'error');
            return;
        }
        
        if (!acceptTerms) {
            showMessage('Você deve aceitar os termos de uso.', 'error');
            return;
        }
        
        // Validação de email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            showMessage('Por favor, insira um email válido.', 'error');
            return;
        }
        
        // Verificar se o email já está cadastrado
        const users = JSON.parse(localStorage.getItem('lemoria_users') || '[]');
        if (users.find(u => u.email === email)) {
            showMessage('Este email já está cadastrado. Faça login ou use outro email.', 'error');
            return;
        }
        
        // Criar novo usuário
        const newUser = {
            email: email,
            name: name,
            password: password, // Em produção, isso deveria ser criptografado
            registeredAt: new Date().toISOString()
        };
        
        // Salvar novo usuário na lista
        users.push(newUser);
        localStorage.setItem('lemoria_users', JSON.stringify(users));
        
        // Cadastro bem-sucedido
        showMessage('Conta criada com sucesso! Você será redirecionado para o login.', 'success');
        
        // Log para demonstração
        console.log('Cadastro realizado:', {
            name: name,
            email: email,
            password: '***'
        });
        
        // Após cadastro bem-sucedido, volta para o login
        setTimeout(() => {
            registerForm.classList.remove('active');
            loginForm.classList.add('active');
            registerFormElement.reset();
        }, 2000);
    });

    // Função para exibir mensagens
    function showMessage(message, type) {
        // Remove mensagem anterior se existir
        const existingMessage = document.querySelector('.message');
        if (existingMessage) {
            existingMessage.remove();
        }
        
        // Cria nova mensagem
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        messageDiv.textContent = message;
        
        // Estilos da mensagem
        messageDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 10px;
            color: white;
            font-weight: 600;
            z-index: 1000;
            animation: slideIn 0.3s ease-out;
            max-width: 300px;
            word-wrap: break-word;
        `;
        
        if (type === 'success') {
            messageDiv.style.background = 'linear-gradient(135deg, #27ae60, #2ecc71)';
        } else if (type === 'error') {
            messageDiv.style.background = 'linear-gradient(135deg, #e74c3c, #c0392b)';
        }
        
        document.body.appendChild(messageDiv);
        
        // Remove a mensagem após 4 segundos
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.style.animation = 'slideOut 0.3s ease-in';
                setTimeout(() => {
                    messageDiv.remove();
                }, 300);
            }
        }, 4000);
    }

    // Adiciona animações CSS para as mensagens
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
        
        .message {
            word-wrap: break-word;
            white-space: pre-wrap;
        }
    `;
    document.head.appendChild(style);

    // Validação em tempo real para senhas
    const registerPassword = document.getElementById('register-password');
    const confirmPassword = document.getElementById('confirm-password');
    
    confirmPassword.addEventListener('input', function() {
        if (this.value && registerPassword.value) {
            if (this.value === registerPassword.value) {
                this.classList.remove('input-error');
                this.classList.add('input-success');
            } else {
                this.classList.remove('input-success');
                this.classList.add('input-error');
            }
        } else {
            this.classList.remove('input-error', 'input-success');
        }
    });

    // Validação de email em tempo real
    const emailInputs = document.querySelectorAll('input[type="email"]');
    emailInputs.forEach(input => {
        input.addEventListener('blur', function() {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (this.value) {
                if (emailRegex.test(this.value)) {
                    this.classList.remove('input-error');
                    this.classList.add('input-success');
                } else {
                    this.classList.remove('input-success');
                    this.classList.add('input-error');
                }
            } else {
                this.classList.remove('input-error', 'input-success');
            }
        });
    });

    // Efeito de foco nos inputs
    const allInputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="password"]');
    allInputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentNode.style.transform = 'scale(1.02)';
            this.parentNode.style.transition = 'transform 0.2s ease';
        });
        
        input.addEventListener('blur', function() {
            this.parentNode.style.transform = 'scale(1)';
        });
    });

    // Verificar se o usuário já está logado
    const user = localStorage.getItem('lemoria_user');
    if (user) {
        // Se já está logado, redirecionar para o dashboard
        window.location.href = 'dashboard.html';
    }

});


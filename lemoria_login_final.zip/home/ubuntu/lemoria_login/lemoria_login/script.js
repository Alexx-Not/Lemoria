// ==================== GERENCIAMENTO DE USUÁRIOS ====================
// Inicializar usuários no localStorage se não existirem
function initializeUsers() {
    if (!localStorage.getItem("lemoria_users")) {
        localStorage.setItem("lemoria_users", JSON.stringify([]));
    }
}

// Obter todos os usuários
function getUsers() {
    return JSON.parse(localStorage.getItem("lemoria_users") || "[]");
}

// Salvar novo usuário
function saveUser(name, email, password) {
    const users = getUsers();
    
    // Verificar se email já existe
    if (users.some(user => user.email === email)) {
        return { success: false, message: "Este email já está cadastrado!" };
    }
    
    users.push({ name, email, password });
    localStorage.setItem("lemoria_users", JSON.stringify(users));
    return { success: true, message: "Cadastro realizado com sucesso!" };
}

// Verificar login
function verifyLogin(email, password) {
    const users = getUsers();
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
        return { success: true, user };
    }
    return { success: false, message: "Email ou senha incorretos!" };
}

// ==================== GERENCIAMENTO DO PERSONAGEM ====================
const clockCharacter = document.getElementById("clock-character");
const characterMessage = document.getElementById("character-message");
const leftEye = document.querySelector("#left-eye .pupil");
const rightEye = document.querySelector("#right-eye .pupil");
const leftEyelid = document.querySelector("#left-eye .eyelid");
const rightEyelid = document.querySelector("#right-eye .eyelid");

// Estados do personagem
const CHARACTER_STATES = {
    NORMAL: "state-normal",
    FOCUSED: "state-focused",
    ERROR: "state-error",
    SUCCESS: "state-success",
    SLEEPY: "state-sleepy" // Novo estado para fechar os olhos
};

// Definir estado do personagem
function setCharacterState(state, message = null) {
    // Remover todos os estados
    Object.values(CHARACTER_STATES).forEach(s => {
        clockCharacter.classList.remove(s);
    });
    
    // Adicionar novo estado
    clockCharacter.classList.add(state);
    
    // Atualizar mensagem se fornecida
    if (message) {
        characterMessage.textContent = message;
    }
}

// Mover olhos do personagem
function moveEyes(x, y) {
    const rect = clockCharacter.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    const angle = Math.atan2(y - centerY, x - centerX);
    const distance = 5;
    
    const leftEyeX = 70 + Math.cos(angle) * distance;
    const leftEyeY = 80 + Math.sin(angle) * distance;
    const rightEyeX = 130 + Math.cos(angle) * distance;
    const rightEyeY = 80 + Math.sin(angle) * distance;
    
    leftEye.setAttribute("cx", leftEyeX);
    leftEye.setAttribute("cy", leftEyeY);
    rightEye.setAttribute("cx", rightEyeX);
    rightEye.setAttribute("cy", rightEyeY);
}

// Resetar olhos para posição normal
function resetEyes() {
    leftEye.setAttribute("cx", 70);
    leftEye.setAttribute("cy", 80);
    rightEye.setAttribute("cx", 130);
    rightEye.setAttribute("cy", 80);
    // Garantir que as pálpebras estão abertas
    if (leftEyelid) leftEyelid.setAttribute("d", "M 55 80 Q 70 65 85 80");
    if (rightEyelid) rightEyelid.setAttribute("d", "M 115 80 Q 130 65 145 80");
}

// Fechar os olhos (para o estado SLEEPY)
function closeEyes() {
    if (leftEyelid) leftEyelid.setAttribute("d", "M 55 80 Q 70 80 85 80"); // Linha reta
    if (rightEyelid) rightEyelid.setAttribute("d", "M 115 80 Q 130 80 145 80"); // Linha reta
    leftEye.setAttribute("r", 0); // Esconder pupilas
    rightEye.setAttribute("r", 0);
}

// ==================== GERENCIAMENTO DE FORMULÁRIOS ====================
const loginForm = document.getElementById("login-form");
const registerForm = document.getElementById("register-form");
const showRegisterLink = document.getElementById("show-register");
const showLoginLink = document.getElementById("show-login");

// Alternar entre formulários
showRegisterLink.addEventListener("click", (e) => {
    e.preventDefault();
    loginForm.classList.remove("active");
    registerForm.classList.add("active");
    setCharacterState(CHARACTER_STATES.NORMAL, "Crie sua conta!");
    resetEyes();
});

showLoginLink.addEventListener("click", (e) => {
    e.preventDefault();
    registerForm.classList.remove("active");
    loginForm.classList.add("active");
    setCharacterState(CHARACTER_STATES.NORMAL, "Bem-vindo de volta");
    resetEyes();
});

// ==================== INTERATIVIDADE DO LOGIN ====================
const loginEmailInput = document.querySelector("#login-form input[type=\"email\"]");
const loginPasswordInput = document.querySelector("#login-form input[type=\"password\"]");
const loginSubmitBtn = document.querySelector("#login-form button[type=\"submit\"]");

// Eventos de foco nos campos de login
loginEmailInput.addEventListener("focus", () => {
    setCharacterState(CHARACTER_STATES.FOCUSED, "Digite seu email...");
    resetEyes();
});

loginPasswordInput.addEventListener("focus", () => {
    setCharacterState(CHARACTER_STATES.SLEEPY, "Digite sua senha..."); // Fechar os olhos
    closeEyes();
});

// Eventos de desfoque
[loginEmailInput, loginPasswordInput].forEach(input => {
    input.addEventListener("blur", () => {
        if (loginEmailInput.value || loginPasswordInput.value) {
            setCharacterState(CHARACTER_STATES.NORMAL, "Quase lá!");
        } else {
            setCharacterState(CHARACTER_STATES.NORMAL, "Bem-vindo de volta");
        }
        resetEyes();
    });
});

// Rastrear movimento do mouse para mover olhos
document.addEventListener("mousemove", (e) => {
    if (loginForm.classList.contains("active") || registerForm.classList.contains("active")) {
        moveEyes(e.clientX, e.clientY);
    }
});

// Envio do formulário de login
document.querySelector("#login-form form").addEventListener("submit", (e) => {
    e.preventDefault();
    
    const email = loginEmailInput.value.trim();
    const password = loginPasswordInput.value.trim();
    
    if (!email || !password) {
        setCharacterState(CHARACTER_STATES.ERROR, "Preencha todos os campos!");
        return;
    }
    
    const result = verifyLogin(email, password);
    
    if (result.success) {
        setCharacterState(CHARACTER_STATES.SUCCESS, `Bem-vindo, ${result.user.name}!`);
        
        // Salvar sessão
        localStorage.setItem("lemoria_current_user", JSON.stringify(result.user));
        
        // Redirecionar após 1.5 segundos
        setTimeout(() => {
            window.location.href = "dashboard.html";
        }, 1500);
    } else {
        setCharacterState(CHARACTER_STATES.ERROR, result.message);
        loginPasswordInput.value = "";
        
        // Voltar ao estado normal após 2 segundos
        setTimeout(() => {
            setCharacterState(CHARACTER_STATES.NORMAL, "Tente novamente");
            resetEyes();
        }, 2000);
    }
});

// ==================== INTERATIVIDADE DO CADASTRO ====================
const registerNameInput = document.querySelector("#register-form input[type=\"text\"]");
const registerEmailInput = document.querySelector("#register-form input[type=\"email\"]");
const registerPasswordInput = document.querySelector("#register-form input[type=\"password\"]");
const confirmPasswordInput = document.querySelector("#confirm-password");
const registerSubmitBtn = document.querySelector("#register-form button[type=\"submit\"]");

// Eventos de foco nos campos de cadastro
[registerNameInput, registerEmailInput, registerPasswordInput, confirmPasswordInput].forEach(input => {
    input.addEventListener("focus", () => {
        setCharacterState(CHARACTER_STATES.FOCUSED, "Preencha com atenção!");
        resetEyes();
    });
    
    input.addEventListener("blur", () => {
        if (registerNameInput.value || registerEmailInput.value || registerPasswordInput.value) {
            setCharacterState(CHARACTER_STATES.NORMAL, "Ótimo!");
        } else {
            setCharacterState(CHARACTER_STATES.NORMAL, "Crie sua conta!");
        }
        resetEyes();
    });
});

// Envio do formulário de cadastro
document.querySelector("#register-form form").addEventListener("submit", (e) => {
    e.preventDefault();
    
    const name = registerNameInput.value.trim();
    const email = registerEmailInput.value.trim();
    const password = registerPasswordInput.value.trim();
    const confirmPassword = confirmPasswordInput.value.trim();
    
    // Validações
    if (!name || !email || !password || !confirmPassword) {
        setCharacterState(CHARACTER_STATES.ERROR, "Preencha todos os campos!");
        return;
    }
    
    if (password !== confirmPassword) {
        setCharacterState(CHARACTER_STATES.ERROR, "As senhas não coincidem!");
        confirmPasswordInput.value = "";
        return;
    }
    
    if (password.length < 6) {
        setCharacterState(CHARACTER_STATES.ERROR, "Senha deve ter 6+ caracteres!");
        return;
    }
    
    if (!email.includes("@")) {
        setCharacterState(CHARACTER_STATES.ERROR, "Email inválido!");
        return;
    }
    
    // Salvar usuário
    const result = saveUser(name, email, password);
    
    if (result.success) {
        setCharacterState(CHARACTER_STATES.SUCCESS, "Conta criada com sucesso!");
        
        // Limpar formulário
        setTimeout(() => {
            registerNameInput.value = "";
            registerEmailInput.value = "";
            registerPasswordInput.value = "";
            confirmPasswordInput.value = "";
            document.querySelector("#accept-terms").checked = false;
            
            // Voltar ao login
            registerForm.classList.remove("active");
            loginForm.classList.add("active");
            setCharacterState(CHARACTER_STATES.NORMAL, "Bem-vindo de volta");
            resetEyes();
        }, 1500);
    } else {
        setCharacterState(CHARACTER_STATES.ERROR, result.message);
        
        setTimeout(() => {
            setCharacterState(CHARACTER_STATES.NORMAL, "Tente novamente");
            resetEyes();
        }, 2000);
    }
});

// ==================== INICIALIZAÇÃO ====================
document.addEventListener("DOMContentLoaded", () => {
    initializeUsers();
    setCharacterState(CHARACTER_STATES.NORMAL, "Bem-vindo de volta");
    
    // Fazer o relógio girar
    const hourHand = document.querySelector(".hour-hand");
    const minuteHand = document.querySelector(".minute-hand");
    
    function updateClock() {
        const now = new Date();
        const hours = now.getHours() % 12;
        const minutes = now.getMinutes();
        const seconds = now.getSeconds();
        
        const hourDegrees = (hours * 30) + (minutes * 0.5);
        const minuteDegrees = (minutes * 6) + (seconds * 0.1);
        
        hourHand.style.transform = `rotate(${hourDegrees}deg)`;
        minuteHand.style.transform = `rotate(${minuteDegrees}deg)`;
    }
    
    updateClock();
    setInterval(updateClock, 1000);

    // Verificar se já está logado
    const currentUser = localStorage.getItem("lemoria_current_user");
    if (currentUser) {
        window.location.href = "dashboard.html"; // Redireciona para o dashboard se já estiver logado
    }
});


// Dashboard JavaScript - Gerenciamento de Recados

class ReminderManager {
    constructor() {
        this.reminders = [];
        this.currentFilter = 'all';
        this.currentSearch = '';
        this.editingId = null;
        this.notificationInterval = null;
        
        this.init();
    }

    init() {
        this.loadReminders();
        this.setupEventListeners();
        this.renderReminders();
        this.startNotificationCheck();
        this.setMinDate();
        this.displayUserName();
    }

    // ==================== Event Listeners ====================
    setupEventListeners() {
        // Criar novo recado
        document.getElementById('reminder-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.addReminder();
        });

        // Logout
        document.getElementById('logout-btn').addEventListener('click', () => {
            this.logout();
        });

        // Filtros
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                this.currentFilter = e.target.dataset.filter;
                this.renderReminders();
            });
        });

        // Busca
        document.getElementById('search-input').addEventListener('input', (e) => {
            this.currentSearch = e.target.value.toLowerCase();
            this.renderReminders();
        });

        // Modal
        const editModal = document.getElementById('edit-modal');
        const modalClose = document.querySelector('.modal-close');
        const cancelEdit = document.getElementById('cancel-edit');

        modalClose.addEventListener('click', () => {
            this.closeModal();
        });

        cancelEdit.addEventListener('click', () => {
            this.closeModal();
        });

        document.getElementById('edit-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.updateReminder();
        });

        // Fechar modal ao clicar fora
        editModal.addEventListener('click', (e) => {
            if (e.target === editModal) {
                this.closeModal();
            }
        });

        // Notificação
        document.querySelector('.notification-close').addEventListener('click', () => {
            this.closeNotification();
        });
    }

    // ==================== CRUD Operations ====================
    addReminder() {
        const title = document.getElementById('reminder-title').value.trim();
        const date = document.getElementById('reminder-date').value;
        const time = document.getElementById('reminder-time').value;
        const message = document.getElementById('reminder-message').value.trim();

        if (!title || !date || !time || !message) {
            this.showMessage('Por favor, preencha todos os campos.', 'error');
            return;
        }

        const reminder = {
            id: Date.now(),
            title,
            date,
            time,
            message,
            completed: false,
            createdAt: new Date().toISOString()
        };

        this.reminders.push(reminder);
        this.saveReminders();
        this.renderReminders();
        
        // Limpar formulário
        document.getElementById('reminder-form').reset();
        
        this.showMessage('Recado adicionado com sucesso!', 'success');
    }

    deleteReminder(id) {
        if (confirm('Tem certeza que deseja deletar este recado?')) {
            this.reminders = this.reminders.filter(r => r.id !== id);
            this.saveReminders();
            this.renderReminders();
            this.showMessage('Recado deletado com sucesso!', 'success');
        }
    }

    openEditModal(id) {
        const reminder = this.reminders.find(r => r.id === id);
        if (!reminder) return;

        this.editingId = id;
        document.getElementById('edit-title').value = reminder.title;
        document.getElementById('edit-date').value = reminder.date;
        document.getElementById('edit-time').value = reminder.time;
        document.getElementById('edit-message').value = reminder.message;

        document.getElementById('edit-modal').classList.add('active');
    }

    closeModal() {
        document.getElementById('edit-modal').classList.remove('active');
        this.editingId = null;
        document.getElementById('edit-form').reset();
    }

    updateReminder() {
        if (this.editingId === null) return;

        const title = document.getElementById('edit-title').value.trim();
        const date = document.getElementById('edit-date').value;
        const time = document.getElementById('edit-time').value;
        const message = document.getElementById('edit-message').value.trim();

        if (!title || !date || !time || !message) {
            this.showMessage('Por favor, preencha todos os campos.', 'error');
            return;
        }

        const reminder = this.reminders.find(r => r.id === this.editingId);
        if (reminder) {
            reminder.title = title;
            reminder.date = date;
            reminder.time = time;
            reminder.message = message;

            this.saveReminders();
            this.renderReminders();
            this.closeModal();
            this.showMessage('Recado atualizado com sucesso!', 'success');
        }
    }

    markAsCompleted(id) {
        const reminder = this.reminders.find(r => r.id === id);
        if (reminder) {
            reminder.completed = !reminder.completed;
            this.saveReminders();
            this.renderReminders();
        }
    }

    // ==================== Rendering ====================
    renderReminders() {
        const remindersList = document.getElementById('reminders-list');
        let filtered = this.getFilteredReminders();

        if (filtered.length === 0) {
            remindersList.innerHTML = '<div class="empty-state"><p>Nenhum recado encontrado.</p></div>';
            return;
        }

        remindersList.innerHTML = filtered.map(reminder => this.createReminderCard(reminder)).join('');
        
        // Adicionar event listeners aos botões
        document.querySelectorAll('.btn-edit').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.target.dataset.id);
                this.openEditModal(id);
            });
        });

        document.querySelectorAll('.btn-delete').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.target.dataset.id);
                this.deleteReminder(id);
            });
        });

        document.querySelectorAll('.btn-mark').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.target.dataset.id);
                this.markAsCompleted(id);
            });
        });
    }

    createReminderCard(reminder) {
        const isCompleted = reminder.completed;
        const completedClass = isCompleted ? 'completed' : '';
        const buttonText = isCompleted ? 'Desmarcar' : 'Marcar como Visto';
        const buttonClass = isCompleted ? 'btn-mark' : 'btn-mark';

        return `
            <div class="reminder-card ${completedClass}">
                <div class="reminder-header">
                    <h3 class="reminder-title">${this.escapeHtml(reminder.title)}</h3>
                    <span class="reminder-badge ${completedClass}">${isCompleted ? 'Visto' : 'Pendente'}</span>
                </div>
                <div class="reminder-datetime">
                    <span class="reminder-date">${this.formatDate(reminder.date)}</span>
                    <span class="reminder-time">${reminder.time}</span>
                </div>
                <div class="reminder-message">${this.escapeHtml(reminder.message)}</div>
                <div class="reminder-actions">
                    <button class="btn-small btn-mark" data-id="${reminder.id}">${buttonText}</button>
                    <button class="btn-small btn-edit" data-id="${reminder.id}">Editar</button>
                    <button class="btn-small btn-delete" data-id="${reminder.id}">Deletar</button>
                </div>
            </div>
        `;
    }

    getFilteredReminders() {
        let filtered = this.reminders;

        // Filtro por status
        if (this.currentFilter === 'pending') {
            filtered = filtered.filter(r => !r.completed);
        } else if (this.currentFilter === 'completed') {
            filtered = filtered.filter(r => r.completed);
        }

        // Filtro por busca
        if (this.currentSearch) {
            filtered = filtered.filter(r =>
                r.title.toLowerCase().includes(this.currentSearch) ||
                r.message.toLowerCase().includes(this.currentSearch)
            );
        }

        // Ordenar por data e hora
        return filtered.sort((a, b) => {
            const dateTimeA = new Date(`${a.date}T${a.time}`);
            const dateTimeB = new Date(`${b.date}T${b.time}`);
            return dateTimeA - dateTimeB;
        });
    }

    // ==================== Notifications ====================
    startNotificationCheck() {
        // Verificar a cada minuto
        this.notificationInterval = setInterval(() => {
            this.checkForNotifications();
        }, 60000); // 60 segundos

        // Verificar imediatamente
        this.checkForNotifications();
    }

    checkForNotifications() {
        const now = new Date();
        const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
        const currentDate = now.toISOString().split('T')[0];

        this.reminders.forEach(reminder => {
            if (!reminder.completed && reminder.date === currentDate && reminder.time === currentTime) {
                this.showNotification(reminder);
                this.showClockNotification(reminder);
                // Marcar como visualizado automaticamente após notificação
                setTimeout(() => {
                    reminder.completed = true;
                    this.saveReminders();
                    this.renderReminders();
                }, 5000);
            }
        });
    }

    showNotification(reminder) {
        const notification = document.getElementById('notification');
        document.getElementById('notification-title').textContent = reminder.title;
        document.getElementById('notification-message').textContent = reminder.message;
        
        notification.classList.add('active');

        // Som de notificação (opcional)
        this.playNotificationSound();

        // Fechar após 10 segundos
        setTimeout(() => {
            this.closeNotification();
        }, 10000);
    }

    showClockNotification(reminder) {
        const clockNotification = document.getElementById('clock-notification');
        document.getElementById('clock-notification-title').textContent = reminder.title;
        document.getElementById('clock-notification-message').textContent = reminder.message;
        
        clockNotification.classList.add('active');

        // Animar o relógio
        this.animateClockNotification();

        // Fechar após 8 segundos
        setTimeout(() => {
            this.closeClockNotification();
        }, 8000);
    }

    closeClockNotification() {
        document.getElementById('clock-notification').classList.remove('active');
    }

    animateClockNotification() {
        const notificationClock = document.querySelector('.notification-clock');
        if (notificationClock) {
            // Animar os olhos piscando
            const pupils = document.querySelectorAll('.notif-pupil');
            pupils.forEach(pupil => {
                pupil.style.opacity = '0';
                setTimeout(() => {
                    pupil.style.opacity = '1';
                }, 200);
                setTimeout(() => {
                    pupil.style.opacity = '0';
                }, 400);
                setTimeout(() => {
                    pupil.style.opacity = '1';
                }, 600);
            });
        }
    }

    closeNotification() {
        document.getElementById('notification').classList.remove('active');
    }

    playNotificationSound() {
        // Criar um som simples usando Web Audio API
        try {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();

            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);

            oscillator.frequency.value = 800;
            oscillator.type = 'sine';

            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);

            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.5);
        } catch (e) {
            console.log('Notificação de som não disponível');
        }
    }

    // ==================== Storage ====================
    saveReminders() {
        localStorage.setItem('lemoria_reminders', JSON.stringify(this.reminders));
    }

    loadReminders() {
        const stored = localStorage.getItem('lemoria_reminders');
        this.reminders = stored ? JSON.parse(stored) : [];
    }

    // ==================== User ====================
    displayUserName() {
        const user = JSON.parse(localStorage.getItem('lemoria_current_user') || '{}');
        const userName = user.name || 'Usuário';
        document.getElementById('user-name').textContent = userName;
    }

    logout() {
        localStorage.removeItem('lemoria_current_user');
        window.location.href = 'index.html';
    }

    // ==================== Utilities ====================
    showMessage(message, type) {
        const notification = document.getElementById('notification');
        document.getElementById('notification-title').textContent = type === 'success' ? 'Sucesso' : 'Erro';
        document.getElementById('notification-message').textContent = message;
        
        notification.classList.add('active');

        setTimeout(() => {
            notification.classList.remove('active');
        }, 3000);
    }

    formatDate(dateString) {
        const date = new Date(dateString + 'T00:00:00');
        return date.toLocaleDateString('pt-BR', { 
            weekday: 'short', 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric' 
        });
    }

    setMinDate() {
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('reminder-date').min = today;
        document.getElementById('edit-date').min = today;
    }

    escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, m => map[m]);
    }
}

// Inicializar quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se o usuário está logado
    const user = localStorage.getItem('lemoria_current_user');
    if (!user) {
        window.location.href = 'index.html';
        return;
    }

    // Inicializar o gerenciador de recados
    new ReminderManager();
});


// Aguarda o carregamento completo da página
document.addEventListener('DOMContentLoaded', function() {
    // Elementos dos formulários
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    
    // Botões para alternar entre formulários
    const showRegisterBtn = document.getElementById('show-register');
    const showLoginBtn = document.getElementById('show-login');
    
    // Formulários
    const loginFormElement = loginForm.querySelector('form');
    const registerFormElement = registerForm.querySelector('form');

    // Função para alternar para o formulário de cadastro
    showRegisterBtn.addEventListener('click', function(e) {
        e.preventDefault();
        loginForm.classList.remove('active');
        registerForm.classList.add('active');
        
        // Limpa os campos do formulário de login
        loginFormElement.reset();
    });

    // Função para alternar para o formulário de login
    showLoginBtn.addEventListener('click', function(e) {
        e.preventDefault();
        registerForm.classList.remove('active');
        loginForm.classList.add('active');
        
        // Limpa os campos do formulário de cadastro
        registerFormElement.reset();
    });

    // Manipulação do formulário de login
    loginFormElement.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        const rememberMe = document.getElementById('remember-me').checked;
        
        // Validação básica
        if (!email || !password) {
            showMessage('Por favor, preencha todos os campos.', 'error');
            return;
        }
        
        // Simulação de login (não funcional)
        showMessage('Login realizado com sucesso!', 'success');
        
        // Log para demonstração
        console.log('Tentativa de login:', {
            email: email,
            password: '***',
            rememberMe: rememberMe
        });
    });

    // Manipulação do formulário de cadastro
    registerFormElement.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const name = document.getElementById('register-name').value;
        const email = document.getElementById('register-email').value;
        const password = document.getElementById('register-password').value;
        const confirmPassword = document.getElementById('confirm-password').value;
        const acceptTerms = document.getElementById('accept-terms').checked;
        
        // Validações básicas
        if (!name || !email || !password || !confirmPassword) {
            showMessage('Por favor, preencha todos os campos.', 'error');
            return;
        }
        
        if (password !== confirmPassword) {
            showMessage('As senhas não coincidem.', 'error');
            return;
        }
        
        if (password.length < 6) {
            showMessage('A senha deve ter pelo menos 6 caracteres.', 'error');
            return;
        }
        
        if (!acceptTerms) {
            showMessage('Você deve aceitar os termos de uso.', 'error');
            return;
        }
        
        // Simulação de cadastro (não funcional)
        showMessage('Conta criada com sucesso!', 'success');
        
        // Log para demonstração
        console.log('Tentativa de cadastro:', {
            name: name,
            email: email,
            password: '***'
        });
        
        // Após cadastro bem-sucedido, volta para o login
        setTimeout(() => {
            registerForm.classList.remove('active');
            loginForm.classList.add('active');
            registerFormElement.reset();
        }, 2000);
    });

    // Função para exibir mensagens
    function showMessage(message, type) {
        // Remove mensagem anterior se existir
        const existingMessage = document.querySelector('.message');
        if (existingMessage) {
            existingMessage.remove();
        }
        
        // Cria nova mensagem
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        messageDiv.textContent = message;
        
        // Estilos da mensagem
        messageDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 10px;
            color: white;
            font-weight: 600;
            z-index: 1000;
            animation: slideIn 0.3s ease-out;
            max-width: 300px;
            word-wrap: break-word;
        `;
        
        if (type === 'success') {
            messageDiv.style.background = 'linear-gradient(135deg, #27ae60, #2ecc71)';
        } else if (type === 'error') {
            messageDiv.style.background = 'linear-gradient(135deg, #e74c3c, #c0392b)';
        }
        
        document.body.appendChild(messageDiv);
        
        // Remove a mensagem após 4 segundos
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.style.animation = 'slideOut 0.3s ease-in';
                setTimeout(() => {
                    messageDiv.remove();
                }, 300);
            }
        }, 4000);
    }

    // Adiciona animações CSS para as mensagens
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);

    // Validação em tempo real para senhas
    const registerPassword = document.getElementById('register-password');
    const confirmPassword = document.getElementById('confirm-password');
    
    confirmPassword.addEventListener('input', function() {
        if (this.value && registerPassword.value) {
            if (this.value === registerPassword.value) {
                this.classList.remove('input-error');
                this.classList.add('input-success');
            } else {
                this.classList.remove('input-success');
                this.classList.add('input-error');
            }
        } else {
            this.classList.remove('input-error', 'input-success');
        }
    });

    // Validação de email em tempo real
    const emailInputs = document.querySelectorAll('input[type="email"]');
    emailInputs.forEach(input => {
        input.addEventListener('blur', function() {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (this.value) {
                if (emailRegex.test(this.value)) {
                    this.classList.remove('input-error');
                    this.classList.add('input-success');
                } else {
                    this.classList.remove('input-success');
                    this.classList.add('input-error');
                }
            } else {
                this.classList.remove('input-error', 'input-success');
            }
        });
    });

    // Efeito de foco nos inputs
    const allInputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="password"]');
    allInputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentNode.style.transform = 'scale(1.02)';
            this.parentNode.style.transition = 'transform 0.2s ease';
        });
        
        input.addEventListener('blur', function() {
            this.parentNode.style.transform = 'scale(1)';
        });
    });

});
